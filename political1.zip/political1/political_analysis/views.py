from django.shortcuts import render
import try_me
list=[]
def politic1(request):
    return render(request,"politic1.html",{"data":list})
def politic2(request):
    if request.method == "POST":
        search=request.POST.get("search:",None)
        result = try_me.analysis(search)
    return render(request,'politic2.html',{"account":result["Account"],"number_of_tweets":result["Number of Tweets"],
                                    "democrat":result["Democrat"],"republican":result["Republican"],"neutral":result["Neutral"]
                                    ,"result":result["Result"]})
