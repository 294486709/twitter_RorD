from django.apps import AppConfig


class PoliticalAnalysisConfig(AppConfig):
    name = 'political_analysis'
