Twitter Republican or Democrat predictor

Please download and place google word2vector library in the directory. 
You can download it from:http://mccormickml.com/2016/04/12/googles-pretrained-word2vec-model-in-python/

The program will use Tensorflow numpy gensim

Please run try_me.py


